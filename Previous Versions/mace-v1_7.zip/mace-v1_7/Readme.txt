Mace
====

    Introduction
    ------------

        Mace will create a new MineCraft world with
          a random city at the spawn point.

        Please see the project page for planned features:
          http://code.google.com/p/mace-minecraft/

        Have fun :)

        Robson
        http://iceyboard.no-ip.org

    Requirements
    ------------

        Mace requires the Microsoft .NET Framework,
          version 4 or later. You probably have this,
          but if necessary it can be obtained from:
          http://go.microsoft.com/fwlink/?LinkID=186913

    Instructions
    ------------

        1. Unzip all the files (Mace.exe, etc) anywhere.
        2. Run Mace.exe and change any options that you'd like.
        3. Click the "Generate City" button.
        4. Open MineCraft and go to the end of your world list.
        5. Play your new city!

