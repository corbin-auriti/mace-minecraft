Mace
====

    Introduction
    ------------

        Mace will create a new MineCraft world with
          a random city at the spawn point.

        I started Mace very recently, so it's quite
          simple at the moment.

        Please see the project page for planned features:
          http://code.google.com/p/mace-minecraft/

        Have fun :)

        Robson
        http://iceyboard.no-ip.org

    Requirements
    ------------

        Mace requires the Microsoft .NET Framework,
          version 2 or later. You probably have this,
          but if necessary it can be obtained from:
          http://go.microsoft.com/fwlink/?LinkID=186913

    Instructions
    ------------

        1. Run Mace.exe and wait while it makes a city for you.
        2. Open MineCraft and go to the end of your world list.
        3. Play your new city!

